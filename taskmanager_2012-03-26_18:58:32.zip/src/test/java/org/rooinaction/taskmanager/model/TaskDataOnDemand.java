package org.rooinaction.taskmanager.model;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Task.class)
public class TaskDataOnDemand {
}
