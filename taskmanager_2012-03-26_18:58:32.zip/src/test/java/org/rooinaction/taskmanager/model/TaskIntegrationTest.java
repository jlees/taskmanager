package org.rooinaction.taskmanager.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Task.class)
public class TaskIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
